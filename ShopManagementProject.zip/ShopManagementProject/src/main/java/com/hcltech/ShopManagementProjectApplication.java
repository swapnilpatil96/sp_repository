package com.hcltech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopManagementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopManagementProjectApplication.class, args);
	}
}
