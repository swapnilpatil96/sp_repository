package com.hcltech.web.api;

import javax.ws.rs.QueryParam;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.model.GeocodingResult;
import com.google.maps.model.LatLng;
import com.hcltech.model.ShopDetails;

@RestController
public class ShopController {

	private static int nextId;

	private static ShopDetails[] shopDetailsArray;
	
	private static final String SHOP_ADDRESS = "SHOP Address:";

	private static ShopDetails saveShop(ShopDetails shopdetails, GeocodingResult[] results) {
		// Initialize the shopDetails array first time.
		if (shopDetailsArray == null) {
			shopDetailsArray = new ShopDetails[10];
			nextId = 0;
		}

		// store the latitude and longitude of shop address.
		if (null != results && results.length > 0) {
			Double latitude = results[0].geometry.location.lat;
			Double longitude = results[0].geometry.location.lng;
			shopdetails.setLatitude(latitude);
			shopdetails.setLongitude(longitude);
		}

		// Adding the shop to the array.
		if (nextId <= 10) {
			shopDetailsArray[nextId] = shopdetails;
			nextId++;
		}

		return shopdetails;
	}


	@RequestMapping(value = "/api/shopdetails", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ShopDetails> shopDetails(@RequestBody ShopDetails shopdetails) throws Exception {

		String address = shopdetails.getShopAddrNum() + shopdetails.getPostCode();

		// Call to Google Maps Geocoding API to retrieve the longitude and
		// latitude for the provided shopAddress.

		GeoApiContext context = new GeoApiContext().setApiKey("AIzaSyA_jw2UYsrBTvUGzdB_SqxToyZQnazdWx4");
		GeocodingResult[] results = GeocodingApi.geocode(context, address).await();

		// Adding the shop in system.
		ShopDetails savedShop = saveShop(shopdetails, results);

		return new ResponseEntity<ShopDetails>(savedShop, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/api/shopLocation", method = RequestMethod.GET)
	public String shopLocation(@QueryParam("latitude") Double latitude,@QueryParam("longitude") Double longitude) throws Exception {

		GeoApiContext context = new GeoApiContext().setApiKey("AIzaSyA_jw2UYsrBTvUGzdB_SqxToyZQnazdWx4");
		
		//Get Latitude and Longitude from url parameters.
		Double lat = latitude;
		Double lng = longitude;

		LatLng location = new LatLng(lat, lng);
		
		// Call to Google Maps Geocoding API to retrieve the address for provided latitude and longitude.
		GeocodingResult[] results = GeocodingApi.reverseGeocode(context, location).await();
		String address = SHOP_ADDRESS;
		// Fetch the address from GeoCoding API response.
		if (null != results && results.length > 0) {
			address = address + results[0].formattedAddress;
		}
		return address;
	}
}
