package com.hcltech.model;

public class ShopDetails {

	private String shopName;
	
	private String shopAddrNum;
	
	private String postCode;
	
	private double latitude;
	
	private double longitude;

	// Address : 1600 Amphitheatre Parkway, Mountain View, CA
	// Postal Code: 94043

	public ShopDetails() {

	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopAddrNum() {
		return shopAddrNum;
	}

	public void setShopAddrNum(String shopAddrNum) {
		this.shopAddrNum = shopAddrNum;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
}
